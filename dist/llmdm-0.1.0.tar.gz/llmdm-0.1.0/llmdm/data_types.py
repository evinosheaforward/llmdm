from dataclasses import dataclass, field
from typing import List, Union


@dataclass
class Relation:
    description: str
    entity1: Union["Person", "Place", "Object"]
    entity2: Union["Person", "Place", "Object"]


@dataclass
class Person:
    name: str
    description: str
    relations: List[Relation] = field(default_factory=list)


@dataclass
class Place:
    name: str
    description: str
    relations: List[Relation] = field(default_factory=list)


@dataclass
class Object:
    name: str
    description: str
    relations: List[Relation] = field(default_factory=list)



class Game:
    def __init__(self):
        self.story = ""

    def prompt(self):
        self.generate_prompt()
        self.user_input = input("What do you do?:")
        self.story += "\n" + self.user_input

    def validate(self):
        self.action = parse_action(self.user_input)
        if not validate_action(action):
            self.respond_invalid_action()


    def resolve(self):

    def repond_invalid_action():




def generate():
    pass


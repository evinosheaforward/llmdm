from pyArango.connection import Connection


class DatabaseWrapper:
    def __init__(
        self,
        db_name,
        host="http://localhost:8529",
        username="root",
        password="password",
    ):
        self.db_name = db_name
        self.username = username
        self.password = password
        self.host = host
        self.conn = self.get_connection()
        self.db = self.get_db()

    def get_connection(self):
        """Establish a connection to the ArangoDB server."""
        return Connection(
            arangoURL=self.host, username=self.username, password=self.password
        )

    def get_db(self):
        """Connect to the specified database, creating it if necessary."""
        if self.db_name in self.conn.databases:
            db = self.conn[self.db_name]
        else:
            db = self.conn.createDatabase(name=self.db_name)
        return db

    def setup_collections(self):
        """Set up the necessary collections and graph."""
        # Create vertex collections for Person, Place, and Object
        for collection_name in ["Person", "Place", "Object"]:
            if collection_name not in self.db.collections:
                self.db.createCollection(name=collection_name)

        # Create the Relation edge collection
        if "Relation" not in self.db.collections:
            self.db.createCollection(className="Edges", name="Relation")

        # Create the graph if it doesn't exist
        if "entity_graph" not in self.db.graphs:
            graph = self.db.createGraph("entity_graph")
            # Add edge definition
            graph.createEdgeDefinition(
                edgeCollection="Relation",
                fromVertexCollections=["Person", "Place", "Object"],
                toVertexCollections=["Person", "Place", "Object"],
            )
            print("Database setup completed.")
        else:
            graph = self.db.graphs["entity_graph"]

    def add_person(self, name, description):
        """Add a person to the database."""
        person_collection = self.db["Person"]
        person = person_collection.createDocument()
        person["_key"] = name
        person["name"] = name
        person["description"] = description
        person.save()
        return person

    def add_place(self, name, description):
        """Add a place to the database."""
        place_collection = self.db["Place"]
        place = place_collection.createDocument()
        place["_key"] = name
        place["name"] = name
        place["description"] = description
        place.save()
        return place

    def add_object(self, name, description):
        """Add an object to the database."""
        object_collection = self.db["Object"]
        obj = object_collection.createDocument()
        obj["_key"] = name
        obj["name"] = name
        obj["description"] = description
        obj.save()
        return obj

    def add_relation(self, from_id, to_id, relation_description):
        """Create a relation between two entities."""
        graph = self.db.graphs["entity_graph"]
        relation_collection = graph.edgeCollections["Relation"]
        relation = relation_collection.createEdge()
        relation["_from"] = from_id
        relation["_to"] = to_id
        relation["description"] = relation_description
        relation.save()
        return relation

    def get_entity_by_id(self, entity_id):
        """Get a specific entity by its document ID."""
        collection_name, key = entity_id.split("/")
        collection = self.db[collection_name]
        return collection[key]

    def get_relations_for_entity(self, entity_id):
        """Find all relations for a specific entity (either incoming or outgoing)."""
        query = """
        FOR edge IN Relation
            FILTER edge._from == @entity_id OR edge._to == @entity_id
            RETURN edge
        """
        bind_vars = {"entity_id": entity_id}
        aql = self.db.AQLQuery(query, bindVars=bind_vars)
        return list(aql)

    def get_related_entities(self, entity_id):
        """Find all entities related to the given entity."""
        query = """
        FOR v, e IN 1..1 ANY @entity_id GRAPH 'entity_graph'
            RETURN { entity: v, relation: e }
        """
        bind_vars = {"entity_id": entity_id}
        aql = self.db.AQLQuery(query, bindVars=bind_vars)
        return list(aql)


# Example usage
if __name__ == "__main__":
    # Initialize the wrapper
    db_wrapper = DatabaseWrapper(db_name="my_graph_db")

    # Set up the database collections and graph
    db_wrapper.setup_collections()

    # Add some entities
    person = db_wrapper.add_person(
        "Alice", "A software engineer with an interest in hiking."
    )
    place = db_wrapper.add_place("MountEverest", "The highest mountain in the world.")
    obj = db_wrapper.add_object("Backpack", "A durable hiking backpack.")

    # Create relations
    db_wrapper.add_relation(person._id, place._id, "Visited in 2020")
    db_wrapper.add_relation(person._id, obj._id, "Owns and uses for hiking")

    print("Entities and relations have been added successfully.")
